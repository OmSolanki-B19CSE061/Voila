class UserID {
  String userId;

  UserID({this.userId});
}
